This .zip archive contains :

- in the Disease_model folder, our code along with the javadoc and the JFreeChart library that we used

- a .jar file that allows to run our program (we added it so that you can run the program without setting the path to the JFreeChart library)

- our report 

- our UML diagram
