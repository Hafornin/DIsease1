/*
 * This is the main class of our program.
 * It creates a startWindow.
 */
package disease;

public class Main {

	public static void main(String[] args) {
		StartWindow w = new StartWindow();
	}

}
